//
//  ViewController.swift
//  FingerprintDemoApp
//
//  Created by yasinkoker on 24.11.2023.
//

import UIKit
import AVFoundation
import PapilonFingerTipDetection

class ViewController: UIViewController {
    
    private var fingerTipDetection: FingerTipDetection?
    private var previewLayer: AVCaptureVideoPreviewLayer?
    private var processedImages: [String: FingerImageData] = [:]  // Store processed images
    private var base64Strings: [String] = []  // Store base64 strings of cropped images
    private var activityIndicator: UIActivityIndicatorView!
    private var overlayView: UIView!


    override func viewDidLoad() {
        super.viewDidLoad()
                
        // Initialize the FingerTipDetection instance
        fingerTipDetection = FingerTipDetection(
            token: "4ad37eebab1462c38867b73e2a4cf7d48144bf176c55716f3abc59e9ce8c61bde8160ab9a8580b54f52daa9b05f4b50d1cae",
            licenceID: "9",
            parentView: self.view)
        fingerTipDetection?.delegate = self
        
        // Setup the activity indicator
        setupActivityIndicator()
        setupOverlayView()
        
        // Request camera permissions
        checkCameraPermissions()
    }
    
    private func setupOverlayView() {
        overlayView = UIView(frame: view.bounds)
        overlayView.backgroundColor = UIColor.orange.withAlphaComponent(0.7) // Semi-transparent orange
        overlayView.isHidden = true // Initially hidden
        view.addSubview(overlayView)
    }
    
    private func checkCameraPermissions() {
        let authStatus = AVCaptureDevice.authorizationStatus(for: .video)
        switch authStatus {
        case .authorized:
            // Permission granted, you can start using the camera
            startAndSetupCamera()
        case .notDetermined:
            // Request permission from the user
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                if granted {
                    self?.startAndSetupCamera()
                } else {
                    // Handle permission denied
                }
            }
        case .denied, .restricted:
            // Handle denied or restricted permissions
            // You can differentiate further if needed
            break
        @unknown default:
            break
        }
    }
    
    private func startAndSetupCamera() {
        fingerTipDetection?.startCamera()
        setupCameraPreview()
    }
    
    private func setupCameraPreview() {
        guard let captureSession = fingerTipDetection?.getCaptureSession() else {
            return
        }

        // Create a preview layer for the camera feed
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer?.videoGravity = .resizeAspectFill
        previewLayer?.frame = view.bounds
        view.layer.insertSublayer(previewLayer!, at: 0)
    }
    
    private func setupActivityIndicator() {
        activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator.center = self.view.center
        activityIndicator.hidesWhenStopped = true
        view.addSubview(activityIndicator)
    }
    
//    // new screen
//        private func navigateToResultsViewController(with base64Strings: [String]) {
//            let resultsVC = ResultsViewController()
//            resultsVC.base64Strings = base64Strings
//            self.navigationController?.pushViewController(resultsVC, animated: true)
//        }
  
    // modally
    private func navigateToResultsViewController() {
        let resultsVC = ResultsViewController()
        resultsVC.base64Strings = base64Strings
        resultsVC.processedImages = processedImages
        self.present(resultsVC, animated: true, completion: nil)
    }
}

extension ViewController: FingerTipDetectionDelegate {
    func operationCompleted(wholeHand: String, indexFinger: String, middleFinger: String, ringFinger: String, pinkyFinger: String) {
        // Store the cropped image data
        base64Strings = [wholeHand, indexFinger, middleFinger, ringFinger, pinkyFinger]
    }
  
    
    func didReceiveProcessedFingerData(_ fingerData: [String: FingerImageData], wsqResults: [String: String]) {
        self.processedImages = fingerData
        navigateToResultsViewController()
    }
    
    func networkRequestDidStart() {
        DispatchQueue.main.async {
            // start the spinner
            self.activityIndicator.startAnimating()
            
            // hide ui elements
            self.previewLayer?.isHidden = true
            
            self.overlayView.isHidden = false // Show the overlay
        }
    }

    func networkRequestDidFinish() {
        DispatchQueue.main.async {
            // stop the spinner
            self.activityIndicator.stopAnimating()
            
            // show the ui elements
            self.previewLayer?.isHidden = false
            
            self.overlayView.isHidden = true // Hide the overlay
        }
    }

}
