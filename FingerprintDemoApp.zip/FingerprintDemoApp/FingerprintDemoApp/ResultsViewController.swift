//
//  ResultsViewController.swift
//  FingerprintDemoApp
//
//  Created by yasinkoker on 24.11.2023.
//

import UIKit
import PapilonFingerTipDetection


class ResultsViewController: UIViewController {
    var base64Strings: [String] = []
    var processedImages: [String: FingerImageData] = [:]
    var scrollView: UIScrollView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        setupScrollView()
        displayImages()
    }

    private func setupScrollView() {
        scrollView = UIScrollView(frame: view.bounds)
        scrollView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(scrollView)
    }

    private func displayImages() {
        var yOffset: CGFloat = 0
        let halfWidth: CGFloat = scrollView.frame.width / 2
        let imageHeight: CGFloat = 200

        for (index, base64String) in base64Strings.enumerated() {
            // Cropped image
            if let imageData = Data(base64Encoded: base64String), let image = UIImage(data: imageData) {
                let imageView = UIImageView(image: image)
                imageView.frame = CGRect(x: 0, y: yOffset, width: halfWidth, height: imageHeight)
                imageView.contentMode = .scaleAspectFit
                scrollView.addSubview(imageView)
            }

            // Processed image
            if let fingerKey = correspondingFingerKey(index),
               let processedImageData = processedImages[fingerKey]?.base64Rgb,
               let processedData = Data(base64Encoded: processedImageData),
               let processedImage = UIImage(data: processedData) {
                let processedImageView = UIImageView(image: processedImage)
                processedImageView.frame = CGRect(x: halfWidth, y: yOffset, width: halfWidth, height: imageHeight)
                processedImageView.contentMode = .scaleAspectFit
                scrollView.addSubview(processedImageView)
            }

            yOffset += imageHeight + 10
        }

        scrollView.contentSize = CGSize(width: scrollView.frame.width, height: yOffset)
    }

    private func correspondingFingerKey(_ index: Int) -> String? {
        // Assuming the order of base64Strings matches these keys
        let keys = ["whole_hand", "left_index", "left_middle", "left_ring", "left_pinky"]
        return index < keys.count ? keys[index] : nil
    }
}
